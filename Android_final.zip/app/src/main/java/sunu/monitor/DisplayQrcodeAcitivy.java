package sunu.monitor;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DisplayQrcodeAcitivy extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);


        String ipport = GetSharedPreference();
        if (ipport.isEmpty()) {
            Log.d("MYT", "SHARED PREF emptry");
            SetSharedPreference("http://raspberrypi.local:5000");
        }
        //RetrofitExService.URL = "ABC";
        Log.d("MYT", "SHAREDPREF:"+ipport);
        MyGlobals.getInstance().setData(ipport);

        String s =  MyGlobals.getInstance().getData();
        Log.d("MYT", "GLOBAL:"+s);
        RequestQrCode();

    }

    public void RequestQrCode(){
        // https://zerodice0.tistory.com/198
        String ip_url =  MyGlobals.getInstance().getData();

        Log.d("MYT", "아이피정보:"+ip_url);

        // Retrofit 설정
        Retrofit retrofit =  new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // Use GSON Converter
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Load Custom Retrofit Interface

        // GET 파라미터 제작
        Map<String, String> loginData = new HashMap<>();

        // HTTP GET 요청
        // ex) BASE_URL/user/login?id=idText&pw=pwText
        retrofitExService.downloadImage("API").enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                InputStream is = response.body().byteStream();
                Bitmap bitmap = BitmapFactory.decodeStream(is);

                //출처: https://zerodice0.tistory.com/198 [검은곰의 아카이브]

                ImageView imageView1 = (ImageView) findViewById(R.id.iv_qrcode) ;
                imageView1.setImageBitmap(bitmap); ;
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(DisplayQrcodeAcitivy.this, "서버 연결 실패", Toast.LENGTH_LONG).show();
            }

        });
    }

    // 새로고침
    public void OnRefresh(View view) {
        RequestQrCode();
    }

    // 뒤로가기
    public void OnBack2(View view) {
        finish();
    }

    String GetSharedPreference() {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정, 만약 test key값이 있다면 해당 값을 불러옴.
        String inputText = sharedPreferences.getString("ipport", "");

        //textView.setText(inputText);    // TextView에 SharedPreferences에 저장되어있던 값 찍기.

        //Toast.makeText(this, "불러오기 하였습니다..", Toast.LENGTH_SHORT).show();
        return inputText;
    }

    void SetSharedPreference(String input) {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정
        SharedPreferences.Editor editor = sharedPreferences.edit(); //sharedPreferences를 제어할 editor를 선언

        editor.putString("ipport", input); // key,value 형식으로 저장
        //editor.putString("inputText", editText.getText().toString()); // key,value 형식으로 저장


        editor.commit();    //최종 커밋. 커밋을 해야 저장이 된다.
        //Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();
    }
}
