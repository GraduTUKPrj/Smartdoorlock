package sunu.monitor;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;


public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    final String TAG = getClass().getSimpleName();
    ImageView imageView;
    Button cameraBtn;
    final static int TAKE_PICTURE = 1;

    String mCurrentPhotoPath;
    static final int REQUEST_TAKE_PHOTO = 1;

    EditText idEdit;
    EditText nameEdit;
    EditText pwEdit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        idEdit = (EditText) findViewById(R.id.edit_id_2);
        pwEdit = (EditText) findViewById(R.id.edit_pw_2);
        nameEdit = (EditText) findViewById(R.id.edit_email);


        String ipport = GetSharedPreference();
        if (ipport.isEmpty()) {
            Log.d("MYT", "SHARED PREF emptry");
            SetSharedPreference("http://raspberrypil.local:5000");
        }
        //RetrofitExService.URL = "ABC";
        Log.d("MYT", "SHAREDPREF:"+ipport);
        MyGlobals.getInstance().setData(ipport);

        String s =  MyGlobals.getInstance().getData();
        Log.d("MYT", "GLOBAL:"+s);


        // 레이아웃과 변수 연결
        imageView = findViewById(R.id.imageview);
        cameraBtn = findViewById(R.id.camera_button);

        // 카메라 버튼에 리스 추가
        cameraBtn.setOnClickListener(this);

        // 6.0 마쉬멜로우 이상일 경우에는 권한 체크 후 권한 요청
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ) {
                Log.d(TAG, "권한 설정 완료");
            } else {
                Log.d(TAG, "권한 설정 요청");
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        }

        Button btn_register = (Button)findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // 유저 입력 데이터 읽고 저장
                String idText = idEdit.getText().toString();
                String pwText = pwEdit.getText().toString();
                String nameText = nameEdit.getText().toString();

                // 채워지지 않은 필드가 있는지 검사
                if (idText.equals("") || pwText.equals("")|| nameText.equals("")) {
                    // 에러 메세지
                    Toast.makeText(getApplicationContext(), "ID/PW를 먼저 입력하세요", Toast.LENGTH_LONG).show();
                } else {

                    if(mCurrentPhotoPath == null){
                        Toast.makeText(RegisterActivity.this, "사진을 먼저 찍어주세요", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(RegisterActivity.this, "등록중입니다. 새로운 이미지 학습을 진행합니다.", Toast.LENGTH_SHORT).show();

                        Log.i("MYT", "REGISTER request"+mCurrentPhotoPath); //storage/emulated/0/1Android/data/com.application.cameraexample/files/Pictures/200921173713.jpg

                        File file = new File(mCurrentPhotoPath);

                        Uri uri = Uri.fromFile(file);
                        Log.i("MYT", "PATH"+uri.getPath());  // /storage/emulated/0/Android/data/com.application.cameraexample/files/Pictures/200921174007.jpg
                        //Log.i("MYT", "STRING"+uri.toString()); // file:///storage/emulated/0/Android/data/com.application.cameraexample/files/Pictures/200921174007.jpg

                        uploadFile(uri);
                    }

                }

            }
        });
    }




    // 권한 요청
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "onRequestPermissionsResult");
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED ) {
            Log.d(TAG, "Permission: " + permissions[0] + "was " + grantResults[0]);
        }
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.camera_button:
                // 카메라 앱을 여는 소스

                // 유저 입력 데이터 읽고 저장
                String idText = idEdit.getText().toString();
                String pwText = pwEdit.getText().toString();
                String nameText = nameEdit.getText().toString();
                Log.d(TAG, "idEdit:" + idText);
                // 채워지지 않은 필드가 있는지 검사
                if (idText.equals("") || pwText.equals("")|| nameText.equals("")) {
                    // 에러 메세지
                    Toast.makeText(getApplicationContext(), "ID/PW를 먼저 입력하세요", Toast.LENGTH_LONG).show();
                } else {
                    dispatchTakePictureIntent();
                }

                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        try {
            switch (requestCode) {

                case REQUEST_TAKE_PHOTO: {
                    if (resultCode == RESULT_OK) {
                        File file = new File(mCurrentPhotoPath);
                        Bitmap bitmap = MediaStore.Images.Media
                                .getBitmap(getContentResolver(), Uri.fromFile(file));

                        if (bitmap != null) {
                            ExifInterface ei = new ExifInterface(mCurrentPhotoPath);
                            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                                    ExifInterface.ORIENTATION_UNDEFINED);

                            Bitmap rotatedBitmap = null;
                            switch (orientation) {

                                case ExifInterface.ORIENTATION_ROTATE_90:
                                    rotatedBitmap = rotateImage(bitmap, 90);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_180:
                                    rotatedBitmap = rotateImage(bitmap, 180);
                                    break;

                                case ExifInterface.ORIENTATION_ROTATE_270:
                                    rotatedBitmap = rotateImage(bitmap, 270);
                                    break;

                                case ExifInterface.ORIENTATION_NORMAL:
                                default:
                                    rotatedBitmap = bitmap;
                            }

                            imageView.setImageBitmap(rotatedBitmap);
                        }
                    }
                    break;
                }
            }

        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(),
                matrix, true);
    }


    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyMMddHHmmss").format(new Date());

        //String idnum = "1111";
        String idnum = timeStamp;

        String idText = idEdit.getText().toString();
        if(idText.equals("")){
            Toast.makeText(RegisterActivity.this, "회원 정보를 확인하세요", Toast.LENGTH_LONG);
            return null;
        }
        String imageFileName = "/" + idText +".jpg";

        Log.d("MYT", "imageFileName: "+imageFileName);
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        String sdPath = storageDir.getAbsolutePath();

        File file = new File(sdPath);
        file.mkdirs();
        sdPath += imageFileName;
        file = new File(sdPath);
        try {
            file.createNewFile();
            //Toast.makeText(mContext, "이미지 디렉토리 및 파일생성 성공~", 1).show();
        } catch(IOException ie){
            //Toast.makeText(mContext, "이미지 디렉토리 및 파일생성 실패", 1).show();
        }

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = file.getAbsolutePath();
        Log.d("MYT", "mCurrentPhotoPath: "+mCurrentPhotoPath);
        return file;
    }


    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "sunu.monitor.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    private void uploadFile(Uri fileUri) {

        Log.i("MYT", "PATH"+fileUri.getPath());  // /storage/emulated/0/Android/data/com.application.cameraexample/files/Pictures/200921174007.jpg

        String ip_url =  MyGlobals.getInstance().getData();
        Log.i("MYT", "uploadFile IP:"+ip_url);

        // Retrofit 설정
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // GSON 사용
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Retrofit Interface 불러오기

        File file = sunu.monitor.FileUtils.getFile(this, fileUri);

        Log.i("MYT", "uploadFile getPath"+file.getPath());

        RequestBody requestFile =
                RequestBody.create(
                        MediaType.parse("image/jpg"),
                        file
                );

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("picture", file.getName(), requestFile);

        // add another part within the multipart request
        String descriptionString = "hello, this is description speaking";
        RequestBody description =
                RequestBody.create(
                        okhttp3.MultipartBody.FORM, descriptionString);

        // finally, execute the request
        Call<ResponseBody> call = retrofitExService.upload(description, body);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {
                Log.v("Upload", "success");
                RequestRegister();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("Upload error:", t.getMessage());
                Toast.makeText(RegisterActivity.this, "사진 업로드에 실패했습니다", Toast.LENGTH_LONG);
            }
        });
    }

    void RequestRegister() {
        String ip_url =  MyGlobals.getInstance().getData();
        Log.i("MYT", "RequestRegister IP:"+ip_url);
        // Retrofit 설정
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // GSON 사용
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Retrofit Interface 불러오기

        // GET 파라미터 제작
        Map<String, String> registerData = new HashMap<>();

        String[] filename_tmp = mCurrentPhotoPath.split("/");
        String id_tmp = filename_tmp[filename_tmp.length-1];

        Log.i("MYT", "id_tmp:"+id_tmp);
        String[] idfile_tmp = id_tmp.split("\\.");
        Log.i("MYT", "idfile_tmp:"+idfile_tmp);
        String id = idfile_tmp[0];

        String idText = idEdit.getText().toString();
        String pwText = pwEdit.getText().toString();
        String nameText = nameEdit.getText().toString();

        registerData.put("id", idText);
        registerData.put("pw", pwText);
        registerData.put("name", nameText);


        // HTTP GET 요청
        retrofitExService.registerUser(registerData).enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                // 응답 상태 확인
                if (response.isSuccessful()) {
                    // body 결과값 저장
                    //Toast.makeText(RegisterActivity.this, "등록하였습니다", Toast.LENGTH_LONG);
                    Data body = response.body();
                    if (body != null) {
                        // 성공/실패 토스트 메세지 제작
                        // getStatus : JSON에서 성공 여부 가져오는 부분
                        Log.i("MYT", "REGISTER SUCCESS");
                        //Toast.makeText(RegisterActivity.this, body.getStatus(), Toast.LENGTH_LONG);

                        // 성공시
                        // "key": 1 -> Success
                        // "key": 0 -> Fail
                        if (body.getKey() == 1) {
                            // 엑티비티 종료
                            Toast.makeText(RegisterActivity.this, "회원 가입을 완료하였습니다.", Toast.LENGTH_SHORT);
                            finish();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Log.i("MYT", "REGISTER FAILURE");
                Toast.makeText(RegisterActivity.this, "등록에 실패하였습니다", Toast.LENGTH_SHORT);

            }
        });
    }



    String GetSharedPreference() {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정, 만약 test key값이 있다면 해당 값을 불러옴.
        String inputText = sharedPreferences.getString("ipport", "");


        //textView.setText(inputText);    // TextView에 SharedPreferences에 저장되어있던 값 찍기.

        //Toast.makeText(this, "불러오기 하였습니다..", Toast.LENGTH_SHORT).show();
        return inputText;
    }

    void SetSharedPreference(String input) {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정
        SharedPreferences.Editor editor = sharedPreferences.edit(); //sharedPreferences를 제어할 editor를 선언

        editor.putString("ipport", input); // key,value 형식으로 저장
        //editor.putString("inputText", editText.getText().toString()); // key,value 형식으로 저장


        editor.commit();    //최종 커밋. 커밋을 해야 저장이 된다.
        //Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();
    }

}
