package sunu.monitor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DisplayStatusActivity extends Activity {

    ArrayList<ItemInfo> movieDataList;
    String strId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displaystatus);

        Intent intent = getIntent();

        strId = intent.getExtras().getString("id");
        Log.d("MYT", "strId id:"+strId);
        RequestAttendInfoStudent(strId);

    }

    public void InitializeListData(ArrayList<ItemInfo> info)
    {
        String a = "";
        for(int i=0;i<info.size();i++) {
            //a += info.get(i).getId() + "\n";
            //a += info.get(i).getStartTime();
        }

        movieDataList =info;

        ListView listView = (ListView)findViewById(R.id.listViewInfoStudent);
        final StatusAdapter myAdapter = new StatusAdapter(this,movieDataList);

        listView.setAdapter(myAdapter);
    }

    public void RequestAttendInfoStudent(final String sid){

        String ip_url =  MyGlobals.getInstance().getData();

        Log.d("MYT", "아이피정보:"+ip_url);

        // Retrofit 설정
        Retrofit retrofit =  new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // Use GSON Converter
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Load Custom Retrofit Interface

        // GET 파라미터 제작
        Map<String, String> loginData = new HashMap<>();
        //String id = "1112"; // TODO:DELETE DEBUG

        // HTTP GET 요청
        // ex) BASE_URL/user/login?id=idText&pw=pwText
        retrofitExService.setAttendinfo_student(sid).enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                // 응답 상태 확인
                if (response.isSuccessful()) {
                    // 응답 body 저장
                    Data body = response.body();
                    if (body != null) {

                        InitializeListData(body.getInfo());

                        // 성공할 경우
                        // "key": 1 -> Success
                        // "key": 0 -> Fail
                        if (body.getKey() == 1) {

                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Toast.makeText(DisplayStatusActivity.this, "서버 연결 실패", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void OnRefresh(View view){
        RequestAttendInfoStudent(strId);
    }

    public void OnDeleteStatus(View view){
        String ip_url =  MyGlobals.getInstance().getData();

        // Retrofit 설정
        Retrofit retrofit =  new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // Use GSON Converter
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Load Custom Retrofit Interface

        // HTTP GET 요청
        // ex) BASE_URL/user/login?id=idText&pw=pwText
        retrofitExService.delete_status(strId).enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                // 응답 상태 확인
                if (response.isSuccessful()) {
                    // 응답 body 저장
                    Data body = response.body();
                    if (body != null) {

                        // 성공할 경우
                        // "key": 1 -> Success
                        // "key": 0 -> Fail
                        if (body.getKey() == 1) {

                            Toast.makeText(DisplayStatusActivity.this, "출입 기록 삭제", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Toast.makeText(DisplayStatusActivity.this, "서버 연결 실패", Toast.LENGTH_LONG).show();
            }
        });

    }
    // 메인메뉴로 돌아가기
    public void OnBack3(View view) {
        Intent intent = new Intent(DisplayStatusActivity.this, UserAcitivity.class);
        intent.putExtra("id",strId);
        startActivity(intent);
        finish();
    }
}
