package sunu.monitor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class StatusAdapter extends BaseAdapter {

    Context mContext = null;
    LayoutInflater mLayoutInflater = null;
    ArrayList<ItemInfo> sample;

    public StatusAdapter(Context context, ArrayList<ItemInfo> data) {
        mContext = context;
        sample = data;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return sample.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public ItemInfo getItem(int position) {
        return sample.get(position);
    }

    @Override
    public View getView(int position, View converView, ViewGroup parent) {
        View view = mLayoutInflater.inflate(R.layout.layout_statuslist, null);

        //ImageView imageView = (ImageView)view.findViewById(R.id.poster);
        TextView tvinfos_time = (TextView)view.findViewById(R.id.tvinfos_time);
        TextView tvinfos_name = (TextView)view.findViewById(R.id.tvinfos_name);
        TextView tvinfos_category = (TextView)view.findViewById(R.id.tvinfos_category);
        TextView tvinfos_temperature = (TextView)view.findViewById(R.id.tvinfos_temperature);

        //imageView.setImageResource(sample.get(position).getImage());


        tvinfos_time.setText(sample.get(position).getTime());
        tvinfos_name.setText(sample.get(position).getName());
        tvinfos_category.setText(sample.get(position).getCategory());
        tvinfos_temperature.setText(sample.get(position).getTemperature());


        return view;
    }

}
