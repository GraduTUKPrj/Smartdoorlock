package sunu.monitor;

public class ItemInfo {
    String time;
    String name;
    String category;
    String temperature;

    public String getTime() {
        return time;
    }

    public String getName() {
        return name;
    }
    public String getCategory() {
        return category;
    }


    public String getTemperature() {
        return temperature;
    }


}
