package sunu.monitor;


import java.util.ArrayList;
import java.util.List;

public class Data {
    private final String status;
    private final int key;
    private final int value;

    private ArrayList<ItemInfo> info;  // 리스트로 데이터 받기 https://flymogi.tistory.com/entry/Retrofit%EC%9D%84-%EC%82%AC%EC%9A%A9%ED%95%B4%EB%B3%B4%EC%9E%90-v202


    public Data(String status, int key, int value, ArrayList<ItemInfo> info) {
        // HTTP Response Body 데이터 포맷
        this.status = status;
        this.key = key;
        this.value = value;
        this.info = info;

    }


    public ArrayList<ItemInfo> getInfo() {
        return info;
    }


    // json에서 status 읽기
    public String getStatus() {
        return status;
    }

    // json에서 key 읽기
    public int getKey() {
        return key;
    }



    // json에서 value 읽기
    public int getValue() {
        return value;
    }



}
