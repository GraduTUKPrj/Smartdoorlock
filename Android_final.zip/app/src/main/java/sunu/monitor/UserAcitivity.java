package sunu.monitor;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class UserAcitivity extends Activity {

    String strId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        Intent intent = getIntent();

        strId = intent.getExtras().getString("id");

        Log.d("MYT", "getExtras id:"+strId);

        String ipport = GetSharedPreference();
        if (ipport.isEmpty()) {
            Log.d("MYT", "SHARED PREF emptry");
            SetSharedPreference("http://raspberrypil.local:5000");
        }
        //RetrofitExService.URL = "ABC";
        Log.d("MYT", "SHAREDPREF:"+ipport);
        MyGlobals.getInstance().setData(ipport);

        String s =  MyGlobals.getInstance().getData();
        Log.d("MYT", "GLOBAL:"+s);

    }


    public void OnRequestExit(View view){
        String ip_url =  MyGlobals.getInstance().getData();
        Log.i("MYT", "OnRequestExit IP:"+ip_url);
        // Retrofit 설정
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // GSON 사용
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Retrofit Interface 불러오기

        // GET 파라미터 제작
        Map<String, String> registerData = new HashMap<>();

        registerData.put("id", strId);

        // HTTP GET 요청
        retrofitExService.request_exit(registerData).enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                // 응답 상태 확인
                if (response.isSuccessful()) {
                    Data body = response.body();
                    if (body != null) {
                        Log.i("MYT", "REGISTER SUCCESS");
                        // "key": 1 -> Success
                        // "key": 0 -> Fail
                        if (body.getKey() == 1) {
                            Toast.makeText(UserAcitivity.this, "퇴실 요청", Toast.LENGTH_SHORT);

                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Log.i("MYT", "REGISTER FAILURE");
                Toast.makeText(UserAcitivity.this, "통신에 실패하였습니다", Toast.LENGTH_SHORT);

            }
        });

    }


    public void OnDeleteUser(View view){

        //ConfirmDialog();
        String ip_url =  MyGlobals.getInstance().getData();
        Log.i("MYT", "OnDeleteUser IP:"+ip_url);
        // Retrofit 설정
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ip_url)                         // API Base URL
                .addConverterFactory(GsonConverterFactory.create())     // GSON 사용
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Retrofit Interface 불러오기

        // GET 파라미터 제작
        Map<String, String> registerData = new HashMap<>();

        registerData.put("id", strId);

        // HTTP GET 요청
        retrofitExService.delete_id(registerData).enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                // 응답 상태 확인
                if (response.isSuccessful()) {
                    // body 결과값 저장
                    //Toast.makeText(RegisterActivity.this, "등록하였습니다", Toast.LENGTH_LONG);
                    Data body = response.body();
                    if (body != null) {
                        // 성공/실패 토스트 메세지 제작
                        // getStatus : JSON에서 성공 여부 가져오는 부분
                        Log.i("MYT", "REGISTER SUCCESS");
                        //Toast.makeText(RegisterActivity.this, body.getStatus(), Toast.LENGTH_LONG);
                        //finish();
                        // 성공시
                        // "key": 1 -> Success
                        // "key": 0 -> Fail
                        if (body.getKey() == 1) {
                            // 엑티비티 종료
                            Toast.makeText(UserAcitivity.this, "회원 삭제", Toast.LENGTH_SHORT);

                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Log.i("MYT", "REGISTER FAILURE");
                Toast.makeText(UserAcitivity.this, "통신에 실패하였습니다", Toast.LENGTH_SHORT);

            }
        });
    }

    public void OnQrcode(View view) {

        Intent intent = new Intent(UserAcitivity.this, DisplayQrcodeAcitivy.class);
        startActivity(intent);
        //finish();

    }


    public void OnDisplayStatus(View view){

        Intent intent = new Intent(UserAcitivity.this, DisplayStatusActivity.class);
        intent.putExtra("id",strId);
        startActivity(intent);
        //finish();

    }

    String GetSharedPreference() {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정, 만약 test key값이 있다면 해당 값을 불러옴.
        String inputText = sharedPreferences.getString("ipport", "");


        //textView.setText(inputText);    // TextView에 SharedPreferences에 저장되어있던 값 찍기.

        //Toast.makeText(this, "불러오기 하였습니다..", Toast.LENGTH_SHORT).show();
        return inputText;
    }

    void SetSharedPreference(String input) {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정
        SharedPreferences.Editor editor = sharedPreferences.edit(); //sharedPreferences를 제어할 editor를 선언

        editor.putString("ipport", input); // key,value 형식으로 저장
        //editor.putString("inputText", editText.getText().toString()); // key,value 형식으로 저장


        editor.commit();    //최종 커밋. 커밋을 해야 저장이 된다.
        //Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();
    }

}
