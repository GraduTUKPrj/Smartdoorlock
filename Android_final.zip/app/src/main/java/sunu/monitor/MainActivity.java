package sunu.monitor;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    EditText idEdit;
    EditText pwEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        String ipport = GetSharedPreference();
        if (ipport.isEmpty()) {
            Log.d("MYT", "SHARED PREF emptry");
            SetSharedPreference("http://raspberrypil.local:5000");
        }
        //RetrofitExService.URL = "ABC";
        Log.d("MYT", "SHAREDPREF:"+ipport);
        MyGlobals.getInstance().setData(ipport);

        String s =  MyGlobals.getInstance().getData();
        Log.d("MYT", "GLOBAL:"+s);


        // 레이아웃 정의
        idEdit = (EditText) findViewById(R.id.edit_id_1);
        pwEdit = (EditText) findViewById(R.id.edit_pw_1);


    }


    // 로그인 로직
    public void OnLogin(View view) {
        String ip_url =  MyGlobals.getInstance().getData();
        // 유저 입력값 얻기
        String idText = idEdit.getText().toString();
        String pwText = pwEdit.getText().toString();

        // 채워지지않은 필드가 있는지 검증
        if (idText.length() < 2 || pwText.length() < 2) {
            // 에러 메시지
            Toast.makeText(MainActivity.this, "Check ID or Password", Toast.LENGTH_LONG).show();
        } else {
            // Retrofit 설정
            Retrofit retrofit =  new Retrofit.Builder()
                    .baseUrl(ip_url)                         // API Base URL
                    .addConverterFactory(GsonConverterFactory.create())     // Use GSON Converter
                    .build();
            RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class); // Load Custom Retrofit Interface

            // GET 파라미터 제작
            Map<String, String> loginData = new HashMap<>();
            loginData.put("id", idText);
            loginData.put("pw", pwText);

            // HTTP GET 요청
            // ex) BASE_URL/user/login?id=idText&pw=pwText
            retrofitExService.loginUser(loginData).enqueue(new Callback<Data>() {
                @Override
                public void onResponse(Call<Data> call, Response<Data> response) {
                    // 응답 상태 확인
                    if (response.isSuccessful()) {
                        // 응답 body 저장
                        Data body = response.body();
                        if (body != null) {
                            // 성공/실패 토스트메세지 발생
                            // getStatus : Get success/fail msg from JSON format
                            //Toast.makeText(getApplicationContext(), body.getStatus(), Toast.LENGTH_LONG).show();
                            // 성공할 경우
                            // "key": 1 -> Success
                            // "key": 0 -> Fail
                            if (body.getKey() == 1) {
                            //if (body.getKey() == 0) { // debug

                                Intent intent = new Intent(getApplicationContext(), UserAcitivity.class);
                                // https://coding-factory.tistory.com/203
                                String idText = idEdit.getText().toString();
                                intent.putExtra("id",idText);
                                startActivity(intent);
                                // 액티비티 종료
                                //finish();
                            }
                            else {   // 로그인 실패
                                Toast.makeText(MainActivity.this, body.getStatus(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }

                @Override
                public void onFailure(Call<Data> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "서버 연결에 실패하였습니다", Toast.LENGTH_LONG).show();
                }
            });
        }
    }



    public void IpInputDialog() {
        //출처: https://answerofgod.tistory.com/83 [The Answer's Engineering Blog]
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setTitle("아이피 설정");
        alert.setMessage("아이피포트를 입력하세요(예. 192.168.123.5:5000");


        final EditText strIP = new EditText(this);
        alert.setView(strIP);

        alert.setPositiveButton("저장", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                String ip = "http://";
                ip += strIP.getText().toString();

                MyGlobals.getInstance().setData(ip);
                SetSharedPreference(ip);
            }
        });


        alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });

        alert.show();
    }

    String GetSharedPreference() {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정, 만약 test key값이 있다면 해당 값을 불러옴.
        String inputText = sharedPreferences.getString("ipport", "");


        //textView.setText(inputText);    // TextView에 SharedPreferences에 저장되어있던 값 찍기.

        //Toast.makeText(this, "불러오기 하였습니다..", Toast.LENGTH_SHORT).show();
        return inputText;
    }

    void SetSharedPreference(String input) {
        SharedPreferences sharedPreferences = getSharedPreferences("test", MODE_PRIVATE);    // test 이름의 기본모드 설정
        SharedPreferences.Editor editor = sharedPreferences.edit(); //sharedPreferences를 제어할 editor를 선언

        editor.putString("ipport", input); // key,value 형식으로 저장
        //editor.putString("inputText", editText.getText().toString()); // key,value 형식으로 저장


        editor.commit();    //최종 커밋. 커밋을 해야 저장이 된다.
        //Toast.makeText(this, "저장되었습니다.", Toast.LENGTH_SHORT).show();
    }


    public void OnButtonRegister(View view){
        Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
        startActivity(intent);

    }


    // 아이피 세팅 버튼
    public void OnButtonSetting(View view) {
        IpInputDialog();
    }
}
