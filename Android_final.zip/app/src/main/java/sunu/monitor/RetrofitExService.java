package sunu.monitor;

import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface RetrofitExService {
    // Base Url - Raspberry pi AP Mode Root Address
    //String URL = "http://192.168.123.2:5000";
    String URL = "http://raspberrypi.local:5000";

    // User Register
    @GET("/register")
    Call<Data> registerUser(
            @QueryMap Map<String, String> options
    );

    // User Login
    @GET("/login")
    Call<Data> loginUser(
            @QueryMap Map<String, String> options
    );

    @GET("/delete_id")
    Call<Data> delete_id(
            @QueryMap Map<String, String> options
    );

    @GET("/request_exit")
    Call<Data> request_exit(
            @QueryMap Map<String, String> options
    );

    @GET("/delete_status")
    Call<Data> delete_status(
            @Query("id") String id
    );

    @GET("/request_status")
    Call<Data> setAttendinfo_student(
            @Query("id") String id
    );

    @GET("images/{apiName}")
    //@Streaming //용량이 적을 경우 @Streaming은 생략이 가능하다.
    // Call<ResponseBody> downloadImage(@Path("apiName") String apiName);
    Call<ResponseBody> downloadImage(@Path("apiName") String apiName);

    @Multipart
    @POST("upload")
    Call<ResponseBody> upload(
            @Part("description") RequestBody description,
            @Part MultipartBody.Part file
    );

}
